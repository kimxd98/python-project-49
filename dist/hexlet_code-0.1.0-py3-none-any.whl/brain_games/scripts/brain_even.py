import prompt


def welcome():
    print('Welcome to the Brain Games!')


def main():
    welcome()
    def welcome_user():
        name = prompt.string('May I have your name? ')
        print(f"Hello, {name}!")
        print('Answer "yes" if the number is even, otherwise answer "no".')

if __name__ == '__main__':
    main()
